var age = 27;

if (age > 20)
{
  alert("Drink to get drunk");
}

age = 27;

if (age == 50){
  alert("Half century");
}

var name = "Maximus";

if (name == "Maximus")
{
  alert("Good afternoon, General.");
}

name = "Decimus";

if (name != "Maximus")
{
  alert("You are not allowed in.");
}

age = 27;

if (age > 17 && age < 21)
{
  alert("Old enough to vote, too young to drink");
}

var sport = "Skydiving";

if (sport == "Bungee jumping" || sport == "Cliff diving" ||
    sport == "Skydiving")
{
  alert("You're extreme!");
}
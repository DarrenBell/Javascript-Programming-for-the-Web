var name = "Marcus";

if (name == "Maximus")
{
	alert("Good afternoon, General.");
}
else
{
	alert("You are not allowed in.");
}
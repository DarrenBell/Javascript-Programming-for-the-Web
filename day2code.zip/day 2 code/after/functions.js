function sandwich(bread, meat)
{
	var sandwich = bread + meat + bread;
	
	return sandwich;
}

var mySandwich = sandwich("rye", "pastrami");

alert(mySandwich);
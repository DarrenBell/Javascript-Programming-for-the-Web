var tables = getElementsByClassName("dataTable");

for (var i = 0, ii = tables.length; i < ii; i++)
{
	// get all tbody elements inside this table
	
	// for each one...
	
		// get all tr elements inside this tbody
		
		// for every SECOND ONE of those...
		
			// assign it the className "alt"
}

function getElementsByClassName(className)
{
	// get all elements in the document
	if (document.all)
	{
		var allElements = document.all;
	}
	else
	{
		var allElements = document.getElementsByTagName("*");
	}
	
	var foundElements = [];
	for (var i = 0, ii = allElements.length; i < ii; i++)
	{
		if (allElements[i].className == className)
		{
			foundElements[foundElements.length] = allElements[i];
		}
	}
	
	return foundElements;
}
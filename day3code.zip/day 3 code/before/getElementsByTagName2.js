var lists = 
var secondList = 
var secondListItems = 

for (var i = 0, ii = secondListItems.length; i < ii; i++)
{
	alert(secondListItems[i].nodeName);
}
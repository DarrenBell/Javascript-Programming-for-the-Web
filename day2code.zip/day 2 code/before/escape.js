var doubleEscape = "";
alert(doubleEscape);
var name = "Marcus";

if (name == "Maximus")
{
	alert("Good afternoon, General.");
}
else if (name == "Marcus")
{
  alert("Good afternoon, Emperor.");
}
else
{
	alert("You are not allowed in.");
}
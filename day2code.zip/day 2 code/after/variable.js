var chameleon = "blue";
alert(chameleon);
alert(sandwich("ham", "white"));

function sandwich(filling, bread)
{
	var message = "Yum! A delicious " + filling + " on " + bread + " sandwich.";
	
	return message;
}
var numbers = [1, 2, 3, 4, 5];

for (var i = 0; i < numbers.length; i++)
{
  numbers[i] *= 2;
}

alert("The last item in the array is " + numbers[numbers.length - 1]);
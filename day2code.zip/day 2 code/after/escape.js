var doubleEscape = "She said \"hide\" in a loud voice.";
alert(doubleEscape);
var rack = [];
rack[0] = "First";
rack[1] = "Second";
alert(rack[1]);
var unbracketed = 4 + 6 * 5;
var bracketed = (4 + 6) * 5;
alert(unbracketed);
alert(bracketed);
var body = document.getElementsByTagName("body")[0];
body.className = "unreadable";
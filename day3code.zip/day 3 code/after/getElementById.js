var target = document.getElementById("pageTitle");

alert(target.nodeName);